import datetime, fcntl, hashlib, json, os, shutil, subprocess
from pathlib import Path
root=Path('/home/t/dev/personal/corgi-remote-network-eval')
out=root/'dist/local-scale-20261108'
plan=json.loads((out/'plan.json').read_text())
replacement=root/'dist/local-scale-diagnostic-r1-32'
if not json.loads((replacement/'cleanup.json').read_text())['clean'] or (replacement/'failure.txt').exists():
 raise RuntimeError('Diagnostic replacement did not pass')
failed=out/'failures/r1-32-attempt1'
failed.parent.mkdir(exist_ok=True)
(out/'r1-32').rename(failed)
shutil.copy2(out/'r1-32.log',failed/'run.log')
replacement.rename(out/'r1-32')
shutil.copy2('/tmp/corgi-local-scale-diagnostic.log',out/'r1-32.log')
record={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'failed_trial':'failures/r1-32-attempt1',
 'reason':'Daemon PID disappeared during attached-mixed-quiet-focus. Initial cleanup removed server.log; cause unproven. No OOM/kernel crash indication and binary unchanged.',
 'replacement':'r1-32',
 'selection':'Repeat the entire failed case; no CPU/bandwidth-based exclusion. Exclude all partial results from failed trial.',
 'environment_change':'UI_DRIVER_KEEP=1 for diagnostic replacement and all remaining runs; only changes harness cleanup retention, not application environment behavior.',
 'remaining':[]}
(out/'continuation.json').write_text(json.dumps(record,indent=2)+'\n')
shutil.copy2(__file__,out/'continuation.py')
with open(f'/tmp/corgi-cpu-benchmark-{os.getuid()}.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 stat=Path(f'/proc/{os.getpid()}/stat').read_text().rsplit(')',1)[1].split()
 env=dict(os.environ,CORGI_CPU_BENCHMARK_LOCK=f'{os.getpid()}:{stat[19]}',UI_DRIVER_KEEP='1')
 for repeat,count in [(1,4),(2,32),(2,4),(2,8)]:
  for name,digest in plan['sources'].items():
   if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest: raise RuntimeError('Source changed: '+name)
  if hashlib.sha256(Path(plan['binary']).read_bytes()).hexdigest()!=plan['binary_sha256']: raise RuntimeError('Binary changed')
  name=f'r{repeat}-{count}'
  command=['taskset','-c','0','bun',str(root/'tools/benchmarks/local_scale/run.ts'),'--binary',plan['binary'],
   '--out',str(out/name),'--agents',str(count),'--repeat',str(repeat),'--seconds','20','--warmup','5',
   '--cpus',plan['placement']['selection']['cpus'],'--scenarios','idle,mixed,spammy','--attachments','attached,detached','--trace','on']
  record['remaining'].append({'trial':name,'command':command})
  (out/'continuation.json').write_text(json.dumps(record,indent=2)+'\n')
  print(json.dumps({'starting':name}),flush=True)
  with (out/(name+'.log')).open('w') as log: result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  if result.returncode: raise RuntimeError('Failed '+name)
  print(json.dumps({'completed':name}),flush=True)
# Retain the daemon logs before removing the private, stopped fixture homes.
for directory in out.glob('r*-*'):
 if not directory.is_dir() or not (directory/'setup.json').exists(): continue
 home=Path(json.loads((directory/'setup.json').read_text())['home'])
 if not str(home).startswith('/tmp/corgi-ui-driver-'): raise RuntimeError('Unexpected fixture home')
 if (home/'server.log').exists(): shutil.copy2(home/'server.log',directory/'server.log')
 if (home/'.local/state/corgi/crash').exists(): shutil.copytree(home/'.local/state/corgi/crash',directory/'crash',dirs_exist_ok=True)
 if home.exists(): shutil.rmtree(home)
